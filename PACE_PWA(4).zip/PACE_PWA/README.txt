P.A.C.E. - installable app (PWA)
================================

WHAT'S IN THIS FOLDER
  index.html            the app
  manifest.webmanifest  app name, colours and icons
  sw.js                 makes the app work offline
  icon-*.png, apple-touch-icon.png, favicon.png   your logo as app icons

NEW: IF "INSTALL" DOESN'T WORK
  Open  <your link>/install.html  in Chrome or Samsung Internet. It checks everything that is needed, shows red crosses for
  anything missing, and has a big Install button when your phone is ready. (Also reachable from the app: Profile > Install >
  "?" > "Install check".)  Re-upload ALL files from this folder to GitHub (Add file > Upload files) so old versions are replaced.

STEP 1 - PUT IT ONLINE (free, about 2 minutes)
An installable app has to be served over https. The easiest way:
  1. Unzip this folder.
  2. Go to https://app.netlify.com/drop  (free account)
  3. Drag the whole PACE_PWA folder onto the page.
  4. Netlify gives you a link such as https://something.netlify.app. Open it to check the app loads.
Other free options: GitHub Pages or Cloudflare Pages (upload the same files).
Opening index.html straight from your computer will show the app, but it cannot be installed that way.

STEP 2 - INSTALL IT ON YOUR PHONE
  iPhone:  open the link in SAFARI > Share button > "Add to Home Screen" > Add.
  Android: open the link in Chrome > menu (three dots) > "Install app" or "Add to Home screen".
  Laptop:  in Chrome or Edge, click the install icon in the address bar.
It then opens full screen with the P.A.C.E. icon, and works without internet after the first visit.

IF YOU CAN'T REINSTALL ON ANDROID / SAMSUNG
  - Make sure you open YOUR hosted https link (e.g. https://something.netlify.app), not the claude.ai preview link.
  - The app now has an "Install" button (Profile tab, and a banner on Home when your browser offers it).
  - Chrome: menu (three dots) > "Install app" / "Add to Home screen".
    Samsung Internet: menu (three lines) > "Add page to" > "Home screen".
  - If the option is missing after you deleted the app: in the browser's settings clear this site's data
    (Chrome: Settings > Site settings > All sites > your site > Clear & reset), close the tab, open the link again, wait a few seconds, then retry.
  - Update the hosted files as well (the version in sw.js is now pace-v3) so phones pick up the new app.

FULL SCREEN (no time / notification bar on top)
  The app now asks Android for FULL SCREEN mode. Because this is set when the app is installed, delete the old
  app from your phone and install it again from the new link. (iPhone cannot fully hide the status bar.)
  Swipe down from the top edge to see the system bar for a moment.

"POWERED BY NETLIFY" BADGE
  This badge is added by Netlify itself on new free-plan sites, so the app's own code cannot remove it.
  In Netlify open your project > Project configuration > General > "Powered by Netlify badge" and turn it OFF.
  If you can't switch it off on your plan, tap "Hide this badge" inside the badge (hides it on that phone),
  or host the same folder on GitHub Pages or Cloudflare Pages, which don't show a badge.

GOOD TO KNOW
  - Your events, tasks and recipes are stored on the device you use. They are not synced between devices.
  - On iPhone, Safari and the home-screen app keep separate data, so start fresh on the home-screen app.
  - Reminders only fire while the app is open.
  - To update the app later: replace index.html on your host, change 'pace-v1' to 'pace-v2' in sw.js, and re-upload.
